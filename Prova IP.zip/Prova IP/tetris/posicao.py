class Position: # cria class Position
    def __init__(self, row, column): # cria o construtor da class Position
        self.row = row  # cria a variavel row
        self.column = column  # cria a variavel column
